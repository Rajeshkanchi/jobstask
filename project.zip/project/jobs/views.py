from django.shortcuts import render
from django.http import HttpResponse,Http404
from django.template import loader
from datetime import datetime
from django.contrib import messages
from.models import Contact



def job(request):
    all_job=hiring.objects.all
    template=loader.get_template('job.html')

    context = {
        'all_job': all_job

    }
    return HttpResponse(template.render(context, request))

def detail(request, job_id):
    try:
        job = hiring.objects.get(pk=job_id)
    except hiring.DoesNotExist:
        raise Http404('not availabe')

    return render(request,'detail.html', {'job': job})

def home(request):
    return render(request,'home.html')

def workfromhome(request):
    return render(request,'workfromhome.html')


def about(request):
    return render(request,'about.html')

def apply(request):
    return render(request,'apply.html')

def contact(request):
    if request.method =="POST":
        name= request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        describe = request.POST.get('describe')
        contact= Contact(name=name,email=email,phone=phone,describe=describe,date=datetime.today())
        contact.save()
        messages.success(request, 'Query sent succesfullyy.')
    return render(request,'contact.html')

def Apply(request):
    if request.method =="POST":
        First_Name = request.POST.get('First_Name')
        Last_Name = request.POST.get('Last_Name')
        Email_Address = request.POST.get('Email_Address')
        Portfolio = request.POST.get('Portfolio')
        Position = request.POST.get('Position')
        Salary = request.POST.get('Salary')
        StartDate = request.POST.get('StartDate')
        Phone = request.POST.get('Phone')
        Fax = request.POST.get('Fax')
        Organization = request.POST.get('Organization')
        skip_CaptchaCode = request.POST.get('skip_CaptchaCode')
        Apply=Apply(First_Name=First_Name,Last_Name=Last_Name,Email_Address=Email_Address,Portfolio=Portfolio,Position=Position,Salary=Salary,StartDate=StartDate,Phone=Phone,Fax=Fax,Organization=Organization,skip_CaptchaCode=skip_CaptchaCode)
        Apply.save()

    return render(request,'apply.html')