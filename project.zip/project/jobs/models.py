from django.db import models

class hiring (models.Model):
    name=models.CharField(max_length=300)
    skills=models.CharField(max_length=300)
    qualifications=models.CharField(max_length=300)
    role=models.CharField(max_length=300)

    def __str__(self):
        return self.name

class details(models.Model):
    ident=models.ForeignKey(hiring,on_delete=models.CASCADE)

    def __str__(self):
        return str (self.pk)

class Contact(models.Model):
    name=models.CharField(max_length=200)
    email = models.CharField(max_length=200)
    phone = models.CharField(max_length=20)
    describe = models.TextField()
    date=models.DateField()
    def __str__(self):
        return self.name

class Apply(models.Model):
    First_Name=models.CharField(max_length=200)
    Last_Name=models.CharField(max_length=200)
    Email_Address=models.CharField(max_length=200)
    Portfolio=models.CharField(max_length=200)
    Position=models.CharField(max_length=200)
    Salary=models.CharField(max_length=200)
    StartDate=models.CharField(max_length=200)
    Phone= models.CharField(max_length=20)
    Fax= models.CharField(max_length=20)
    Organization=models.CharField(max_length=100)
    skip_CaptchaCode=models.CharField(max_length=6)

    def __str__(self):
        return self.First_Name





